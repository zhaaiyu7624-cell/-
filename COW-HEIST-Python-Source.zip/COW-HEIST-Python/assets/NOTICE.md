# Hand Landmarker model

Google MediaPipe Hand Landmarker, float16 revision 1.
Distributed under the Apache License, Version 2.0 (see LICENSE).

Upstream model URL:
https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task

This copy matches the pinned static distribution ptmaker-vision-models@1.0.0.
SHA-256: fbc2a30080c3c557093b5ddfc334698132eb341044ccee322ccf8bcf3607cde1.
