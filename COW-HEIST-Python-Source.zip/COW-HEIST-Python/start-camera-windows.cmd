@echo off
call "%~dp0start-windows.cmd" --camera
